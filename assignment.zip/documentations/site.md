# Site Documentation


Simply Activate our theme inside Wordpress and You already have a cool landing page. Everything is customizable inside our theme and you can customize them in whatever way you want!.

Our theme has a hard-coded form using php and PHP validation so user can actively and ready to use our form when they activate our theme to their new website
